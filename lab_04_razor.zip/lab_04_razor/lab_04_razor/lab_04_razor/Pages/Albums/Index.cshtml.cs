﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using lab_04_razor.Data;
using lab_04_razor.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace lab_04_razor.Pages.Albums
{
    public class IndexModel : PageModel
    {
        private readonly lab_04_razor.Data.lab_04_razorContext _context;

        public IndexModel(lab_04_razor.Data.lab_04_razorContext context)
        {
            _context = context;
        }

        public IList<Audio> Audio { get;set; } = default!;

        [BindProperty(SupportsGet = true)]
        public string? SearchString { get; set; }

        public SelectList? Genres { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? AlbumGenre { get; set; }

        //public async Task OnGetAsync()
        //{
        //    var albums = from a in _context.Audio
        //                 select a;
        //    if (!string.IsNullOrEmpty(SearchString))
        //    {
        //        albums = albums.Where(s => s.Title.Contains(SearchString));
        //    }

        //    Audio = await albums.ToListAsync();
        //}

        public async Task OnGetAsync()
        {
            // Use LINQ to get list of genres.
            IQueryable<string> genreQuery = from a in _context.Audio
                                            orderby a.Genre
                                            select a.Genre;

            var albums = from a in _context.Audio
                         select a;

            if (!string.IsNullOrEmpty(SearchString))
            {
                albums = albums.Where(s => s.Title.Contains(SearchString));
            }

            if (!string.IsNullOrEmpty(AlbumGenre))
            {
                albums = albums.Where(x => x.Genre == AlbumGenre);
            }
            Genres = new SelectList(await genreQuery.Distinct().ToListAsync());
            Audio = await albums.ToListAsync();
        }
    }
}
