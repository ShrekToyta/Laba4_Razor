﻿using Microsoft.EntityFrameworkCore;
using lab_04_razor.Data;

namespace lab_04_razor.Models;

public class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new lab_04_razorContext(
            serviceProvider.GetRequiredService<
                DbContextOptions<lab_04_razorContext>>()))
        {
            if (context == null || context.Audio == null)
            {
                throw new ArgumentNullException("Null RazorPagesMovieContext");
            }

            // Look for any movies.
            if (context.Audio.Any())
            {
                return;   // DB has been seeded
            }

            context.Audio.AddRange(
                new Audio
                {
                    Title = "Конец света",
                    ReleaseDate = DateTime.Parse("2008-10-15"),
                    Genre = "Rock",
                    Price = 9.99M,
                    Artist = "Би-2",
                    TCount = 12,
                    AlbumLength = 50,
                },

                new Audio
                {
                    Title = "Песни птиц",
                    ReleaseDate = DateTime.Parse("2014-4-14"),
                    Genre = "Indie",
                    Price = 12.99M,
                    Artist = "Мумий Тролль",
                    TCount = 11,
                    AlbumLength = 44,
                },

                new Audio
                {
                    Title = "Танцы над водой",
                    ReleaseDate = DateTime.Parse("2003-5-22"),
                    Genre = "rd",
                    Price = 14.99M,
                    Artist = "Земфира",
                    TCount = 10,
                    AlbumLength = 37,
                },

                new Audio
                {
                    Title = "Ну вот и все, что было",
                    ReleaseDate = DateTime.Parse("2016-9-16"),
                    Genre = "Pop",
                    Price = 10.99M,
                    Artist = "Lumen",
                    TCount = 14,
                    AlbumLength = 49,
                }
            );
            context.SaveChanges();
        }
    }
}
