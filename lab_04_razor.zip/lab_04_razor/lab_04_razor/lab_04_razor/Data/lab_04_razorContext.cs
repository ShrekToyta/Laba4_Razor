﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using lab_04_razor.Models;

namespace lab_04_razor.Data
{
    public class lab_04_razorContext : DbContext
    {
        public lab_04_razorContext (DbContextOptions<lab_04_razorContext> options)
            : base(options)
        {
        }

        public DbSet<lab_04_razor.Models.Audio> Audio { get; set; } = default!;
    }
}
